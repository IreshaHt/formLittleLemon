import BookingForm from "../components/BookForm";

export default function BookPage(){
    return (<>
       <BookingForm />
    </>
   )
}